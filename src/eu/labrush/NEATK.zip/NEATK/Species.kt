package eu.labrush.NEATK

import eu.labrush.NEATK.fellow.Fellow

class Species constructor(var ambassador: Fellow) {

    /**************************
     * Fellows management
     */

    internal var fellows = mutableListOf<Fellow>()

    internal var age = 0
    internal var last_improved = 0
    internal var last_fitness = 0.0

    init {
        this.fellows.add(ambassador)
    }

    internal operator fun get(i: Int): Fellow {
        return fellows[i]
    }

    internal val random: Fellow
        get() = fellows[(Math.random() * (fellows.size + 1)).toInt() % fellows.size]

    internal fun addFellow(f: Fellow) {
        this.fellows.add(f)
    }

    private fun sortFellows() {
        this.fellows.sortedWith(compareBy(Fellow::fitness))
    }

    /**************************
     * NEAT
     */

    internal fun averageFitness(): Double {
        var avg = 0.0

        for (f in this.fellows) {
            avg += f.fitness
        }

        avg /= this.fellows.size.toDouble()

        return avg
    }

    val isStagnant: Boolean
        get() = age - last_improved > Config.max_stagnation

}
