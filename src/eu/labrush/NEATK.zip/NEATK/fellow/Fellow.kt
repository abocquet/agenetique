package eu.labrush.NEATK.fellow

import eu.labrush.NEATK.Config
import eu.labrush.NEATK.utils.Indexer

class Fellow(sensors: Int, outputs: Int) {

    var nodes = mutableMapOf<Int, Node>()
    var connections = mutableMapOf<Int, Connection>()

    var nodeIndexer = Indexer(0)
    var connectionIndexer = Indexer(0)

    init {
        val sensors_id = arrayOfNulls<Node>(sensors)
        for (i in 0..sensors - 1) {
            val newNode = Node(nodeIndexer.next(), NodeType.SENSOR)
            addNode(newNode)
            sensors_id[i] = newNode
        }
        for (i in 0..outputs - 1) {
            val newNode = Node(nodeIndexer.next(), NodeType.OUTPUT)
            addNode(newNode)

            for (j in 0..sensors - 1) {
                this.addConnection(Connection(connectionIndexer.next(), newNode, sensors_id[j]!!))
            }
        }
    }

    /*************************
     * GA stuffs
     */

    var fitness = 0.0
    private var output_number = 0

    /*************************
     * Topology management
     */
    internal fun addNode(n: Node) {
        if (n.type == NodeType.OUTPUT) output_number++
        nodes.put(n.id, n)
    }

    fun removeNode(node: Node) {
        val iter = connections.entries.iterator()
        while (iter.hasNext()) {
            val entry = iter.next()
            val c0 = entry.value
            if (c0.from.id == node.id || c0.to.id == node.id) {
                iter.remove()
            }
        }

        nodes.remove(node.id)
    }

    fun addConnection(c: Connection) {
        val iter = connections.entries.iterator()
        while (iter.hasNext()) {
            val entry = iter.next()
            val c0 = entry.value
            if (c0.from.id == c.from.id && c.to.id == c0.to.id || c0.from.id == c.to.id && c.from.id == c0.to.id) {
                iter.remove()
            }
        }

        this.connections.put(c.id, c)
    }

    fun removeConnection(c: Connection) {
        connections.remove(c.id)
    }

    // Cf eq 3.1 in NEAT PhD
    fun distanceTo(f: Fellow): Double {

        var D = 0.0
        var E = 0.0
        var W = 0.0

        val max = connections.keys.max() ?: 0
        var c = 0

        for (key in f.connections.keys) {

            if (key > max) {
                E++
            } else if (this.connections.containsKey(key)) {
                c++
                W += Math.abs(f.connections[key]!!.weight - this.connections[key]!!.weight)
            } else {
                D++
            }

        }

        this.connections.keys
                .filterNot { f.connections.containsKey(it) }
                .forEach { D++ }

        var dist = D * Config.compatibility_disjoint_coefficient + E // TODO: no multiplier ? see python code

        if (c != 0) {
            dist += W / c * Config.compatibility_weight_coefficient
        }

        return dist
    }

    /*************************
     * Neural network
     */

    internal fun sigmoid(x: Double): Double {
        return 1 / (1 + Math.exp(-x))
    }

    // On procède récursivement sur les noeuds en utilisant la programmation dynamique
    // ex:
    //         7        8
    //        / \     /
    //       6   \   /
    //      /  \<- 5
    //     4      /  \
    //       \ -> 3   2
    //
    // 7
    //  => 6
    //      => 4
    //          => 3 OK
    //      => 5
    //          => 3 OK
    //          => 2 OK
    //  => 5 OK (mémoisé)
    //  8
    //  => 5 OK (mémoisé)
    //
    private fun thinkAboutAux(n: Int, values: DoubleArray): Double {
        if (java.lang.Double.isNaN(values[n])) {

            var s = connections.values
                    .filter { it.to.id == n && it.enabled }
                    .sumByDouble { it.weight * thinkAboutAux(it.from.id, values) }

            s += this.nodes[n]!!.bias
            values[n] = sigmoid(s)
        }

        return values[n]

    }

    fun thinkAbout(input: DoubleArray): DoubleArray { // Activates neural network

        val values = DoubleArray(nodes.keys.max()!!) // We guarantee the parameters are always given in the same order to the network

        var c = 0
        for (key in nodes.keys.sorted()) {
            if (nodes[key]!!.type == NodeType.SENSOR) {
                values[key] = input[c]
                c++
            }
        }

        val output = DoubleArray(output_number)

        try {
            c = 0
            for (key in nodes.keys.sorted()) {
                if (nodes[key]!!.type == NodeType.OUTPUT) {
                    output[c] = thinkAboutAux(key, values)
                    c++
                }
            }
        } catch (e: StackOverflowError) {
            e.printStackTrace()
            println(nodes)
            println(connections)

            System.exit(-1)
        }

        return output
    }

    /*************************
     * MISC
     */

    protected fun copy(): Fellow {
        val f = Fellow(0, 0)

        f.nodes = HashMap(this.nodes)
        f.connections = HashMap(this.connections)
        f.output_number = this.output_number
        f.fitness = this.fitness

        return f
    }

    override fun toString(): String {
        return "fellow{" +
                "fitness=" + fitness +
                '}'
    }

}
