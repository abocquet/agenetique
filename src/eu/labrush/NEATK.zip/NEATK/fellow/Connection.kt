package eu.labrush.NEATK.fellow

import eu.labrush.NEATK.Config
import eu.labrush.NEATK.utils.Random


class Connection (id: Int, var to: Node, var from: Node) : Cloneable {

    var id = 0

    var weight: Double = 0.toDouble()
    var enabled = true

    init {
        if (from.above(to)) {
            this.to = from
            this.from = to
        } else {
            this.from = from
            this.to = to
        }

        this.id = id
        randomWeight()
    }

    /**
     * NEAT
     */

    fun randomWeight() {
        this.weight = Random.gauss(Config.weight_init_stdev, Config.weight_min_value, Config.weight_max_value)
    }

    /**
     * Override
     */

    override fun clone(): Connection {
        val c = Connection(id, to, from)
        c.weight = weight
        c.enabled = enabled
        return c
    }

    /*@Override
    public String toString() {
        return "Connection{" +
                "from=" + from +
                ", to=" + to +
                ", #=" + evolutionNumber +
                ", weight=" + weight +
                ", enabled=" + enabled +
                '}';
    }*/

    override fun toString(): String {
        return "{ " + from.id + " -> " + to.id + "}\n"
    }

}
