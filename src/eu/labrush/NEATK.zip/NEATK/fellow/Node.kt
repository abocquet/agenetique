package eu.labrush.NEATK.fellow

import eu.labrush.NEATK.Config
import eu.labrush.NEATK.utils.Random

enum class NodeType {
    SENSOR, OUTPUT, HIDDEN
}


/**
 * On représente les couches du réseau par des rationnels entre 0 et 1 pour éviter les cycles
 * Une connection ne peut aller de x vers y ssi x < y ou y.above(x) en java
 */
class Node {
    var id: Int = 0
        private set
    internal var numerator: Int = 0
    internal var denominator: Int = 0

    internal var bias: Double = 0.toDouble()

    internal var type = NodeType.HIDDEN

    constructor(id: Int, numerator: Int, denominator: Int) {
        val pgcd = pgcd(numerator, denominator)

        this.numerator = numerator / pgcd
        this.denominator = denominator / pgcd
        this.bias = Random.gauss(Config.response_init_stdev, Config.response_min_value, Config.response_max_value)
    }

    constructor(id: Int, n1: Node, n2: Node) {
        Node(id, n1.numerator * n2.denominator + n2.numerator * n1.denominator, n1.denominator * n2.denominator * 2)
    }

    constructor(id: Int, type: NodeType) {
        if (type == NodeType.OUTPUT) {
            this.numerator = 1
            this.denominator = 1
        } else if (type == NodeType.SENSOR) {
            this.numerator = 0
            this.denominator = 1
        } else {
            try {
                throw Exception("Cannot create node without knowing type nor fraction")
            } catch (e: Exception) {
                e.printStackTrace()
            }

        }

        this.type = type
        this.id = id
    }

    // A/B > nA/nB
    fun above(n: Node): Boolean {
        return numerator * n.denominator > n.numerator * denominator
    }

    fun frontOf(n: Node): Boolean {
        return numerator * n.denominator == n.numerator * denominator
    }


    fun pgcd(a: Int, b: Int): Int {
        if (a == 0) {
            return b
        } else if (a == 1 || b == 1) {
            return 1
        } else if (b == 0) {
            return 0
        } else if (b >= a) {
            return pgcd(b % a, a)
        } else {
            return pgcd(a % b, b)
        }
    }
}
