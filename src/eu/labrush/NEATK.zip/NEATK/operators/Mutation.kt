package eu.labrush.NEATK.operators

import eu.labrush.NEATK.Config
import eu.labrush.NEATK.fellow.Connection
import eu.labrush.NEATK.fellow.Fellow
import eu.labrush.NEATK.fellow.Node
import eu.labrush.NEATK.utils.Random
import eu.labrush.NEATK.utils.Random.random
import java.util.*

object Mutation {

    internal fun addConnectionMutation(f: Fellow) {

        var from: Node
        var to: Node
        val nodes = ArrayList(f.nodes.values)

        var trials = 0 // We don't try for too long, especially at the begginng, new connections cannot be added
        val trial_limit = 10

        do {
            from = random(nodes) as Node
            to = random(nodes) as Node
            trials++
        } while (from.frontOf(to) && trials < trial_limit)

        if (from.frontOf(to)) {
            return
        }

        if (from.above(to)) { // Pour éviter les cycles, (Démonstration par l'absurde: a -> b -> c -> a => a < b < c < a => a < a => absurde)
            val tmp = from
            from = to
            to = tmp
        }

        f.addConnection(Connection(f.connectionIndexer.next(), to, from))
    }

    internal fun addNodeMutation(f: Fellow) {

        val keys = ArrayList(f.connections.keys)

        if (keys.size == 0) {
            addConnectionMutation(f)
            return
        }

        val n = keys[random(f.connections.size - 1)] //The index of the connection on which we are going to addFellow the node
        val c = f.connections[n]!!

        c.enabled = false

        val newNode = Node(f.nodeIndexer.next(), c.from, c.to)
        f.addNode(newNode)
        f.addConnection(Connection(f.connectionIndexer.next(), newNode, c.from))
        f.addConnection(Connection(f.connectionIndexer.next(), c.to, newNode))
    }

    fun delConnectionMutation(f: Fellow) {
        if (f.connections.isEmpty()) {
            return
        }

        f.removeConnection(random(f.connections.values) as Connection)
    }


    fun delNodeMutation(f: Fellow) {
        val n = random(f.nodes.values) as Node

        if (n.numerator == 1 && n.denominator == 1 || n.numerator == 0 && n.denominator == 1) {
            return
        }

        f.removeNode(n)
    }

    fun changeNodeBias(f: Fellow) {
        val n = Random.random(f.nodes.values) as Node
        n.bias = Math.random() * (Config.bias_max_value - Config.bias_min_value) + Config.bias_min_value
    }

}
