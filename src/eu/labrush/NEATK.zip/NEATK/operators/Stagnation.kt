package eu.labrush.NEATK.operators

class Stagnation {
}