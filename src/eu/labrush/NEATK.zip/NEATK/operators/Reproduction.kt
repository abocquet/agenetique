package eu.labrush.NEATK.operators

class Reproduction {

    var indexer = eu.labrush.NEATK.utils.Indexer(0)

}
