package eu.labrush.NEATK

import eu.labrush.NEATK.fellow.Fellow

class Population(val POPSIZE: Int, val inputs: Int, val outputs: Int) {

    val population = Array<Fellow>(Config.pop_size) { _ -> Fellow(inputs, outputs) }
    val generation = 0

}