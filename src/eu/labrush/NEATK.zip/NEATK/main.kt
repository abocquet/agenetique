package eu.labrush.NEATK

fun main(){
    print("coucou")
}