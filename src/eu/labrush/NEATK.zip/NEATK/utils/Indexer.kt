package eu.labrush.NEATK.utils


class Indexer(var c: Int) {

    fun next(): Int {
        c++
        return c
    }

    fun current(): Int {
        return c
    }

}