package eu.labrush.NEATK.utils

import java.util.*

object Random {

    internal var r = java.util.Random()

    /**
     * @param max
     * *
     * @return a number in [0, max - 1]
     */
    internal fun random(max: Int): Int {
        if (max == 0) {
            return 0
        }

        return (Math.random() * (max + 1).toDouble()).toInt() % max
    }

    fun random(u: List<*>): Any {
        return u[random(u.size)]!!
    }

    fun random(u: Collection<*>): Any {
        return random(ArrayList(u))
    }

    fun gauss(stdev: Double, max: Double, min: Double): Double {
        val v = r.nextGaussian() * stdev
        if (v < min) {
            return min
        } else if (v > max) {
            return max
        } else {
            return v
        }
    }

}
